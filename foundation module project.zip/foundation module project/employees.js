// Dummy employee data
const employees = [
  {
    employeeId: 1,
    name: "Sibongile Nkosi",
    position: "Software Engineer",
    department: "Development",
    salary: 70000,
    employmentHistory: "Joined in 2015, promoted to Senior in 2018",
    contact: "sibongile.nkosi@moderntech.com"
  },
  {
    employeeId: 2,
    name: "Lungile Moyo",
    position: "HR Manager",
    department: "HR",
    salary: 80000,
    employmentHistory: "Joined in 2013, promoted to Manager in 2017",
    contact: "lungile.moyo@moderntech.com"
  },
  {
    employeeId: 3,
    name: "Thabo Molefe",
    position: "Quality Analyst",
    department: "QA",
    salary: 55000,
    employmentHistory: "Joined in 2018",
    contact: "thabo.molefe@moderntech.com"
  },
  {
    employeeId: 4,
    name: "Keshav Naidoo",
    position: "Sales Representative",
    department: "Sales",
    salary: 60000,
    employmentHistory: "Joined in 2020",
    contact: "keshav.naidoo@moderntech.com"
  },
  {
    employeeId: 5,
    name: "Zanele Khumalo",
    position: "Marketing Specialist",
    department: "Marketing",
    salary: 58000,
    employmentHistory: "Joined in 2019",
    contact: "zanele.khumalo@moderntech.com"
  },
  {
    employeeId: 6,
    name: "Sipho Zulu",
    position: "UI/UX Designer",
    department: "Design",
    salary: 65000,
    employmentHistory: "Joined in 2016",
    contact: "sipho.zulu@moderntech.com"
  },
  {
    employeeId: 7,
    name: "Naledi Moeketsi",
    position: "DevOps Engineer",
    department: "IT",
    salary: 72000,
    employmentHistory: "Joined in 2017",
    contact: "naledi.moeketsi@moderntech.com"
  },
  {
    employeeId: 8,
    name: "Farai Gumbo",
    position: "Content Strategist",
    department: "Marketing",
    salary: 56000,
    employmentHistory: "Joined in 2021",
    contact: "farai.gumbo@moderntech.com"
  },
  {
    employeeId: 9,
    name: "Karabo Dlamini",
    position: "Accountant",
    department: "Finance",
    salary: 62000,
    employmentHistory: "Joined in 2018",
    contact: "karabo.dlamini@moderntech.com"
  },
  {
    employeeId: 10,
    name: "Fatima Patel",
    position: "Customer Support Lead",
    department: "Support",
    salary: 58000,
    employmentHistory: "Joined in 2016",
    contact: "fatima.patel@moderntech.com"
  }
];

// Function to create employee cards
function displayEmployees() {
  const container = document.getElementById("employee-cards");
  container.innerHTML = ""; // Clear container

  employees.forEach(emp => {
    const card = document.createElement("div");
    card.className = "employee-card";

    card.innerHTML = `
      <h4>${emp.name}</h4>
      <p><strong>Position:</strong> ${emp.position}</p>
      <p><strong>Department:</strong> ${emp.department}</p>
      <p><strong>Email:</strong> ${emp.contact}</p>
      <p><strong>Salary:</strong> $${emp.salary.toLocaleString()}</p>
      <p><strong>History:</strong> ${emp.employmentHistory}</p>
    `;

    container.appendChild(card);
  });
}

// Initialize
displayEmployees();

// Add employee form
document.getElementById("add-employee-form").addEventListener("submit", function(e){
  e.preventDefault();
  
  const newEmployee = {
    employeeId: employees.length + 1,
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    department: document.getElementById("department").value,
    position: document.getElementById("position").value,
    salary: parseFloat(document.getElementById("salary").value),
    employmentHistory: "New hire"
  };

  // Add to employees array
  employees.push(newEmployee);

  // Reset form
  e.target.reset();

  // Refresh cards
  displayEmployees();
});
